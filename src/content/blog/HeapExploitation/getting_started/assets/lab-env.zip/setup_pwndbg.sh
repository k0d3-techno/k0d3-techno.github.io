#!/bin/bash

echo "[+] Installing pwndbg ...."

git clone https://github.com/pwndbg/pwndbg.git

echo "[+] Done!!"
echo "[+] Setup for docker environment"


cd pwndbg
git checkout 2023.03.19
cd ..
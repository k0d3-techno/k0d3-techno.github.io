#!/bin/bash

IMAGE_NAME="lab-env"
CONTAINER_NAME="my_container"

# Color definitions
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${CYAN}[+] Building Docker image '${IMAGE_NAME}'...${NC}"
docker build -t $IMAGE_NAME .

# Check if user passed "--reset"
if [ "$1" == "--reset" ]; then
    echo -e "${YELLOW}[+] Removing old container '${CONTAINER_NAME}' (if exists)...${NC}"
    docker rm -f $CONTAINER_NAME 2>/dev/null
fi

# Create new container only if it doesn't exist
if [ ! "$(docker ps -a -q -f name=^/${CONTAINER_NAME}$)" ]; then
    echo -e "${GREEN}[+] Creating new container '${CONTAINER_NAME}' from image '${IMAGE_NAME}'...${NC}"
    docker run -dit --privileged --name $CONTAINER_NAME $IMAGE_NAME
else
    echo -e "${YELLOW}[=] Container '${CONTAINER_NAME}' already exists. Reusing it.${NC}"
fi

# Open interactive shell in the container
echo -e "${CYAN}[+] Attaching to container '${CONTAINER_NAME}'...${NC}"
docker exec -it $CONTAINER_NAME bash
